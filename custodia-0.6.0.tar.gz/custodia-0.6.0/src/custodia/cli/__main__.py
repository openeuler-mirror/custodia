# Copyright (C) 2016  Custodia Project Contributors - see LICENSE file
from __future__ import absolute_import

from custodia.cli import main

if __name__ == '__main__':
    main()
