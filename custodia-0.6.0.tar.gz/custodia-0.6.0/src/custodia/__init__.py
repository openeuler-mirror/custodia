# custodia namespace
# You must NOT include any other code and data in __init__.py
__import__('pkg_resources').declare_namespace(__name__)
