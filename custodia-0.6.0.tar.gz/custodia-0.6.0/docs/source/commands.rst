#################
Custodia commands
#################

custodia server
===============

.. argparse::
   :ref: custodia.server.default_argparser
   :prog: custodia


custodia client
===============

.. argparse::
   :ref: custodia.cli.main_parser
   :prog: custodia-cli
