configparser extension
======================

:download:`cfgparser.py <cfgparser.py>`

.. literalinclude:: cfgparser.py
