FreeIPA Plugins
===============

.. warning:: IPA plugins are a tech preview with a provisional API.

.. autosummary::
   :nosignatures:

   custodia.ipa.interface.IPAInterface
   custodia.ipa.vault.IPAVault
   custodia.ipa.certrequest.IPACertRequest

.. autoclass:: custodia.ipa.interface.IPAInterface
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: custodia.ipa.vault.IPAVault
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: custodia.ipa.certrequest.IPACertRequest
    :members:
    :undoc-members:
    :show-inheritance:
