Stores
======

.. autosummary::
   :nosignatures:

   custodia.store.sqlite.SqliteStore
   custodia.store.encgen.EncryptedOverlay

.. autoclass:: custodia.store.sqlite.SqliteStore
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: custodia.store.encgen.EncryptedOverlay
    :members:
    :undoc-members:
    :show-inheritance:
