Consumers
=========

.. autosummary::
   :nosignatures:

   custodia.secrets.Secrets
   custodia.forwarder.Forwarder
   custodia.root.Root

.. autoclass:: custodia.secrets.Secrets
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: custodia.forwarder.Forwarder
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: custodia.root.Root
    :members:
    :undoc-members:
    :show-inheritance:
